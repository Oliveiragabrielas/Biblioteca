<?php
include "../includes/conexao.php";

$nome = $_POST['nome'];

$stmt = $conn->prepare("INSERT INTO membros (nome) VALUES (?)");
$stmt->bind_param("s", $nome);
$stmt->execute();

header("Location: ../membros.php");
exit;
?>
