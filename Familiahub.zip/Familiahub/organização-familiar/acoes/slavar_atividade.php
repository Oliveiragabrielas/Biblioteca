<?php
include "../includes/conexao.php";

$atividade = $_POST['atividade'];
$data      = $_POST['data'];
$tipo      = $_POST['tipo'];

$stmt = $conn->prepare(
  "INSERT INTO atividades (atividade, data, tipo) VALUES (?, ?, ?)"
);
$stmt->bind_param("sss", $atividade, $data, $tipo);
$stmt->execute();

header("Location: ../atividades.php");
exit;
?>
