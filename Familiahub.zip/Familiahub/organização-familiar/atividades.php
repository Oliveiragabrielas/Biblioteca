<?php include "includes/conexao.php"; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Atividades</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/menu.php"; ?>

<main class="content">
  <div class="card">
    <h2>Gestão de Atividades</h2>

    <form action="acoes/salvar_atividade.php" method="POST">
      <input type="text" name="atividade" placeholder="Atividade" required>
      <input type="date" name="data" required>

      <select name="tipo">
        <option>Escola</option>
        <option>Esporte</option>
        <option>Outro</option>
      </select>

      <button class="acao">Cadastrar</button>
    </form>

    <h3>Lista</h3>
    <ul>
      <?php
      $sql = "SELECT * FROM atividades ORDER BY data";
      $res = $conn->query($sql);
      while ($a = $res->fetch_assoc()) {
        echo "<li>{$a['data']} → {$a['atividade']} ({$a['tipo']})</li>";
      }
      ?>
    </ul>
  </div>
</main>

</body>
</html>
