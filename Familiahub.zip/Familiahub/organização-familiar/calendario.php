<?php include "includes/conexao.php"; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Calendário</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/menu.php"; ?>

<main class="content">
  <div class="card">
    <h2>Calendário de Atividades</h2>

    <ul>
      <?php
      $sql = "SELECT * FROM atividades ORDER BY data";
      $res = $conn->query($sql);
      while ($a = $res->fetch_assoc()) {
        echo "<li>{$a['data']} → {$a['atividade']}</li>";
      }
      ?>
    </ul>
  </div>
</main>

</body>
</html>
