<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Organizador Familiar</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/menu.php"; ?>

<main class="content">
  <div class="card">
    <h1>Bem-vindo ao Organizador Familiar</h1>
    <p>Sistema nível TCC com PHP + MySQL.</p>
  </div>
</main>

</body>
</html>
