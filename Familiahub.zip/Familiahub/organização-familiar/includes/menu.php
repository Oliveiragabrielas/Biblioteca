<aside class="sidebar">
  <h2>📅 Menu</h2>

  <a href="index.php" class="menu-btn">🏠 Início</a>
  <a href="membros.php" class="menu-btn">👨‍👩‍👧 Membros</a>
  <a href="atividades.php" class="menu-btn">🏫 Atividades</a>
  <a href="calendario.php" class="menu-btn">📆 Calendário</a>
</aside>
