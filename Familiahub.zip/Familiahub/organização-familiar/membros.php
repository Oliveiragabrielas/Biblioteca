<?php include "includes/conexao.php"; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Membros</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/menu.php"; ?>

<main class="content">
  <div class="card">
    <h2>Cadastro de Membros</h2>

    <form action="acoes/salvar_membro.php" method="POST">
      <input type="text" name="nome" placeholder="Nome do membro" required>
      <button class="acao">Adicionar</button>
    </form>

    <h3>Lista</h3>
    <ul>
      <?php
      $sql = "SELECT * FROM membros ORDER BY id DESC";
      $res = $conn->query($sql);
      while ($m = $res->fetch_assoc()) {
        echo "<li>{$m['nome']}</li>";
      }
      ?>
    </ul>
  </div>
</main>

</body>
</html>
